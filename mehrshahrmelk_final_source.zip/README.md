# MehrshahrMelk source + GitHub Actions
Follow README_BUILD.md to build signed APK via GitHub Actions.